package br.com.microservice.pedido.domain.value_objects;

public enum StatusPedido {
    CRIADO,
    PROCESSANDO,
    PROCESSADO,
    FINALIZADO,
    CANCELADO
}
