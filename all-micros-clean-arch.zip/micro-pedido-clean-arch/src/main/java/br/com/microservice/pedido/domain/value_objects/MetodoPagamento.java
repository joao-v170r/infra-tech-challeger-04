package br.com.microservice.pedido.domain.value_objects;

public enum MetodoPagamento {
    BOLETO,
    PIX
}