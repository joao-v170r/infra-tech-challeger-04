package br.com.microservice.pagamento.domain.value_objects;

public enum MetodoPagamento {
    BOLETO,
    PIX
}
