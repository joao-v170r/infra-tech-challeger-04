package br.com.microservice.pagamento.domain.value_objects;

public enum StatusPagamento {
    PENDENTE,
    CONCLUIDO,
    CANCELADO,
    REEMBOLSADO
}
