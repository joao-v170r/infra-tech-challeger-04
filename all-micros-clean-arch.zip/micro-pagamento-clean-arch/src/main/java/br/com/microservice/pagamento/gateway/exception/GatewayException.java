package br.com.microservice.pagamento.gateway.exception;

public interface GatewayException {
    //Futuras implementações
}
