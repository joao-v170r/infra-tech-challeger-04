package br.com.microservice.produto.gateway.exception;

public interface GatewayException {
    //Futuras implementações
}
