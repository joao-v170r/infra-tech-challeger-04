package br.com.microservice.receiver.domain.values_object;

public enum MetodoPagamento {
    BOLETO,
    PIX
}