package br.com.microservice.cliente.gateway.exception;

public interface GatewayException {
    //Futuras implementações
}
