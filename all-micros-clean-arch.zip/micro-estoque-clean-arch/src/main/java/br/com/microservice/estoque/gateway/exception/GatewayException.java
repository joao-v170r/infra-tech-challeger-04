package br.com.microservice.estoque.gateway.exception;

public interface GatewayException {
    //Futuras implementações
}
