package br.com.microservice.estoque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueProdutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueProdutoApplication.class, args);
	}

}
